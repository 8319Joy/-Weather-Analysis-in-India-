import Header from './components/Header'
import TemperatureMap from './components/TemperatureMap'
import RainfallChart from './components/RainfallChart'
import ClimateZones from './components/ClimateZones'

export default function Home() {
  return (
    <main className="min-h-screen bg-cover bg-center" style={{ backgroundImage: "url('/india-weather-bg.jpg')" }}>
      <div className="bg-black bg-opacity-70 min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold text-white mb-8 text-center">Weather Analysis in India</h1>
          
          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-white mb-4">Temperature Map</h2>
            <TemperatureMap />
          </section>
          
          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-white mb-4">Rainfall Distribution</h2>
            <RainfallChart />
          </section>
          
          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-white mb-4">Climate Zones</h2>
            <ClimateZones />
          </section>
        </div>
      </div>
    </main>
  )
}

