const climateZones = [
  { name: 'Tropical Wet', color: 'bg-green-500' },
  { name: 'Tropical Dry', color: 'bg-yellow-500' },
  { name: 'Subtropical Humid', color: 'bg-blue-500' },
  { name: 'Montane', color: 'bg-purple-500' },
  { name: 'Arid', color: 'bg-red-500' },
]

export default function ClimateZones() {
  return (
    <div className="bg-white p-4 rounded-lg shadow-lg">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {climateZones.map((zone) => (
          <div key={zone.name} className={`${zone.color} p-4 rounded text-white text-center`}>
            {zone.name}
          </div>
        ))}
      </div>
    </div>
  )
}

