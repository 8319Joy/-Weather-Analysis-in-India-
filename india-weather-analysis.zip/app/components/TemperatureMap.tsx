'use client'

import { useState } from 'react'

const temperatureData = {
  'North India': { summer: 40, winter: 10 },
  'South India': { summer: 35, winter: 20 },
  'East India': { summer: 38, winter: 15 },
  'West India': { summer: 42, winter: 18 },
  'Central India': { summer: 45, winter: 12 },
}

export default function TemperatureMap() {
  const [season, setSeason] = useState('summer')

  return (
    <div className="bg-white p-4 rounded-lg shadow-lg">
      <div className="mb-4">
        <button
          className={`mr-2 px-4 py-2 rounded ${season === 'summer' ? 'bg-red-500 text-white' : 'bg-gray-200'}`}
          onClick={() => setSeason('summer')}
        >
          Summer
        </button>
        <button
          className={`px-4 py-2 rounded ${season === 'winter' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
          onClick={() => setSeason('winter')}
        >
          Winter
        </button>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {Object.entries(temperatureData).map(([region, temps]) => (
          <div key={region} className="bg-gray-100 p-4 rounded">
            <h3 className="font-semibold">{region}</h3>
            <p>{season === 'summer' ? temps.summer : temps.winter}°C</p>
          </div>
        ))}
      </div>
    </div>
  )
}

