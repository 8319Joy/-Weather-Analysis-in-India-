'use client'

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

const rainfallData = [
  { month: 'Jan', rainfall: 20 },
  { month: 'Feb', rainfall: 30 },
  { month: 'Mar', rainfall: 40 },
  { month: 'Apr', rainfall: 50 },
  { month: 'May', rainfall: 100 },
  { month: 'Jun', rainfall: 250 },
  { month: 'Jul', rainfall: 300 },
  { month: 'Aug', rainfall: 280 },
  { month: 'Sep', rainfall: 200 },
  { month: 'Oct', rainfall: 100 },
  { month: 'Nov', rainfall: 50 },
  { month: 'Dec', rainfall: 30 },
]

export default function RainfallChart() {
  return (
    <div className="bg-white p-4 rounded-lg shadow-lg" style={{ height: '400px' }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={rainfallData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis label={{ value: 'Rainfall (mm)', angle: -90, position: 'insideLeft' }} />
          <Tooltip />
          <Legend />
          <Bar dataKey="rainfall" fill="#8884d8" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

