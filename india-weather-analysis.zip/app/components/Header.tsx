import Link from 'next/link'

export default function Header() {
  return (
    <header className="bg-blue-900 text-white p-4">
      <nav className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">India Weather Analysis</Link>
        <ul className="flex space-x-4">
          <li><Link href="#temperature">Temperature</Link></li>
          <li><Link href="#rainfall">Rainfall</Link></li>
          <li><Link href="#climate-zones">Climate Zones</Link></li>
        </ul>
      </nav>
    </header>
  )
}

